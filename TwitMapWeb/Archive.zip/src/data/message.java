package data;

public class message {
	
	String username;
	String content;
	String location;
	double geoLat;
	double geoLong;

}
